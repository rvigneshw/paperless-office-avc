<!DOCTYPE html>
<html>

<?php include_once('header.php');?>
<body>
    <div>
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button">
            <div class="container"><a class="navbar-brand" href="#">
                Paperless Office

            </a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigatio
                n</span><span class="navbar-toggler-icon">

            </span>
        </button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    <ul class="nav navbar-nav mr-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#">First Item

                        </a>
                    </li>
                        <!-- <li class="nav-item" role="presentation"><a class="nav-link" href="#">Second Item

                        </a> -->
                    </li>
                        <li class="dropdown nav-item"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Dropdown 

                        </a>
                            <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="#">First Item

                            </a>
                            <a class="dropdown-item" role="presentation" href="#">Second Item

                            </a>
                            <a class="dropdown-item" role="presentation" href="#">Third Item

                            </a>
                        </div>
                        
                        </li>
                    
                    </ul><span class="navbar-text actions"> <a class="login" href="#">Log In

                    </a><a class="btn btn-light " role="button" href="#">Log Out

                    </a>
                </span>
                </div>
            
                </div>
        
        </nav>
    
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js">
    </script>

</body>


</html>